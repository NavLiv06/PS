%   run this command to make new classifier with your sound database

%   use .wav files
%   all sound files must be at same frequency-sampling
%   make sure categorized sound files in folders (with apropirate names)


Trainer('\trainFiles');

% this files at trainFiles folder is OPEN and CLOSE sound in PERSIAN-Speach